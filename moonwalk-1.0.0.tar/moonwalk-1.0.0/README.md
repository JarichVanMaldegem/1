# moonwalk
Cover your tracks during Linux Exploitation/Penetration Testing by leaving zero traces on system logs and filesystem timestamps.
