mod core;
mod start;

fn main() -> std::io::Result<()> {    
    start::init()
}
