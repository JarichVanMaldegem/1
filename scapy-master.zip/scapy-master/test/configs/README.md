### UTscapy configs

- OS specifics: bsd, linux, solaris, windows
- Other:
  - cryptography -> used for downstream testing by pyca/cryptography
