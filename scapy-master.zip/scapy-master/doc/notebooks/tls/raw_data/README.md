This folder is used in the notebook and in some tests.

Files in this folder are therefore cross licensed under both GPLv2 and CC-BY-NC-SA 2.5.
