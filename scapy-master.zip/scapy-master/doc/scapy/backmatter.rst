
*******
Credits
*******

The maintainers of Scapy are:
  - Pierre Lalet
  - Gabriel Potter (Lead maintainer)
  - Guillaume Valadon
  - Nils Weiss

Former maintainers include:
  - Philippe Biondi, who was Scapy's original author.

Other documentation credits include:
- Fred Raynal wrote the chapter on building and dissecting packets.
- Peter Kacherginsky contributed several tutorial sections, one-liners and recipes.
- Dirk Loss integrated and restructured the existing docs to make this book.
